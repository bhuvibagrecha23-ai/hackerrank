import csv
import json
import os

repo = r'C:\Users\bhuvi\.gemini\antigravity\scratch\hackerrank-orchestrate-october26'
sample_reqs = list(csv.DictReader(open(os.path.join(repo, 'dataset/sample_deletion_requests.csv'), encoding='utf-8')))
activities = list(csv.DictReader(open(os.path.join(repo, 'dataset/system_activity.csv'), encoding='utf-8')))
sample_truth = {r['case_id']: json.loads(r['steps_json']) for r in csv.DictReader(open(os.path.join(repo, 'dataset/sample_output.csv'), encoding='utf-8'))}

# Look at batch ending 2026-09-06T12:00:00Z
batch_reqs = [r for r in sample_reqs if r['reported_at'] == '2026-09-06T12:00:00Z']
print("Requests in batch:")
for r in batch_reqs:
    print(f"  {r['case_id']} | {r['email']} | {r['reported_status']}")
    # print truth account
    for s in sample_truth[r['case_id']]:
        if s['system_id'] == 'account_service':
            print(f"    Truth account: {s['resource_id']}")

worker_acts = [
    a for a in activities 
    if a['source_system'] == 'deletion_worker' and a['target_system'] == 'account_service'
    and '2026-09-06' in a['event_time'] and '10:' in a['event_time'] or '11:' in a['event_time']
]
print("\nWorker account activities on 2026-09-06 morning:")
for a in worker_acts:
    print(f"  {a['event_time']} | {a['resource_id']} | {a['reported_result']}")
