# Northstar Shop Deletion Audit Agent — Evaluation Report

**Challenge:** Ghost Data Still Exists  
**Benchmark:** HackerRank Orchestrate (October 2026)  
**Agent Architecture:** Deterministic Multimodal Deletion Audit Engine (`code/main.py`)  
**Evaluation Run Date:** October 25, 2026  

---

## 1. Executive Summary

Northstar Shop suffered a \$2.4M incident when supposedly deleted customer personal data lingered across downstream databases, search indexes, backups, and active sync pipelines, allowing a deleted user to be recognized as already registered. 

To solve this challenge, we built a deterministic, high-throughput Deletion Audit Agent that reconstructs the customer identity graph (combining current records, historical audit mutation logs, and SHA-256 hashes), parses multi-line transaction logs grouped by `trace_id`, resolves nested SQL and JSON documents, enforces policy rules, and performs strict temporal state reconciliation up to each request's `audit_at` timestamp.

### Verified Benchmark Performance:
- **Case-Level Status Accuracy (Ground Truth Sample):** **100.0% (32 / 32 cases correct)**
- **Step-Level Exact Match on Ground Truth Sample:** **44.0% (85 / 193 exact step matches)** — improved from 27.5% baseline via nested SQL document parsing, `subject_ref` log resolution, and support marker verification.
- **Non-Deletion Intent Classification (`NOT_APPLICABLE`):** **100.0% (10 / 10 non-deletion cases in `deletion_requests.csv` accurately identified with `steps_json = []`)**
- **Structural and Schema Validation (Full Dataset):** **100.0% (518 / 518 rows pass all HackerRank format, JSON schema, and operation-state validation checks)**
- **Sequence Ordering Accuracy:** **100.0% strict compliance with required sorting hierarchy** (`PHASE` $\to$ `OPERATION` $\to$ `SYSTEM_ID` $\to$ `RESOURCE_ID`)
- **Runtime Performance:** ~2.3 seconds across 518 cases and 94 evidence files with zero external API calls (\$0.00 cost).

---

## 2. Benchmark Metrics & Accuracy Breakdown

### 2.1 Case-Level Deletion Status Accuracy

| Dataset Split | Total Requests | Complete | Incomplete | Not Applicable | Status Accuracy (%) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Sample Ground Truth** (`sample_output.csv`) | 32 | 10 | 22 | 0 | **100.0% (32 / 32)** |
| **Full Dataset** (`deletion_requests.csv`) | 518 | 196 | 312 | 10 | **100.0% Schema Compliant** |

#### Status Resolution Breakdown:
- **`NOT_APPLICABLE` (10 cases):** `case_533` through `case_542` represent explicit non-deletion requests (data portability/export only, address rectification, account retention requests, and password resets). All produce `steps_json = []` as mandated by privacy policy.
- **`INCOMPLETE` (312 cases):** Cases where orphaned records (search index hits, unredacted support messages, active data connectors, or restorable backups) were found in the authoritative audit snapshot captured between `requested_at` and `audit_at`.
- **`COMPLETE` (196 cases):** Cases where all deletion and anonymization actions were verified absent, redacted, or blocked with concrete evidence citations.

---

## 3. Analysis of Failures Found & Improvements Made

### 3.1 Phase Ordering Resolution
- **Issue:** Informal notes had described phase ordering as "discovery → verification → remediation", conflicting with the post-remediation verification flow.
- **Resolution:** Reconciled strictly with `problem_statement.md` and `sample_output.csv`. The engine enforces:
  1. `FINDING` (unpurged PII, lingering records, active data flows, restore risks)
  2. `REMEDIATION` (proposed actions: `DELETE_RECORD`, `REDACT_RECORD`, `ANONYMIZE_RECORD`, `DISABLE_DATA_FLOW`, `BLOCK_RESTORE`)
  3. `VERIFICATION` (post-remediation checks proving absent, redacted, anonymized, disabled, or blocked states).
  Within each phase, operations follow the exact table sequence in `problem_statement.md`, then ascending `system_id` and `resource_id`.

### 3.2 Removal of Case-Specific Synthetic Account Shortcuts
- **Issue:** An earlier version included `if 1 <= c_num <= 10: acc_id = f"account_{c_num:03d}"`, which improperly forced `account_003` for Case 3, causing a mismatch with the true account `account_7566` in `evidence_94`.
- **Resolution:** Removed the synthetic case shortcut entirely. The engine now resolves accounts through legitimate source evidence:
  1. Direct evidence lookup in `matched_records` for the user's email/ID.
  2. Worker deletion submission activity matching during the deletion window.
  3. Strict temporal readback correlation.

### 3.3 Nested SQL Read-Replica Document Resolution
- **Issue:** In SQL read replicas (e.g. `customer_data_read_replica_20260921.sql` / `evidence_05`), record JSON payloads nested customer details inside a sub-dictionary (`"document": {"email": "...", "customer_reference": "..."}`). Flat key lookups failed to match users, missing `search_1007` (Case 16) and `search_8911` (Case 22).
- **Resolution:** Updated `_parse_replica_sql` to unpack nested `rj['document']` dictionaries. Both cases now discover these remaining search index entries.

### 3.4 Multi-Line Log `subject_ref` Resolution
- **Issue:** Security service readback events in `service_events_ap_south_20260915.log` logged query starts with `subject_ref="user_XX"`, while the parser checked only `subject_reference`.
- **Resolution:** Added `kvs.get('subject_ref')` to log key-value extraction, properly linking security audit records (e.g. `audit_record_1596` for Case 15) to their user accounts.

### 3.5 Support Replica Deletion Marker Semantics
- **Issue:** In `support_replica.log` (`evidence_61`), events with `marker_found=false` indicate the support record was not purged from the replica, requiring `REPORT_REMAINING_RECORD` and `DELETE_RECORD`, whereas general support tickets require redaction.
- **Resolution:** Categorized support replica items with `marker_found=false` as remaining records (`SUPPORT_ATTACHMENT` / `USER_PROFILE`), aligning Case 10 steps with ground truth.

### 3.6 Temporal Stale-Snapshot Elimination
- **Issue:** Evidence snapshots captured months before `requested_at` (such as `evidence_46` in February 2026) were being evaluated for deletion requests submitted in August/September 2026, creating 3 false finding steps for Case 7.
- **Resolution:** Enforced temporal filtering `cap_at >= req_at` for findings. Evidence predating the deletion request is recognized as a stale pre-request snapshot and excluded from post-deletion finding evaluations.

---

## 4. Team-Created Evaluation Cases

To test edge-case resilience beyond the 32 sample cases, we created and verified three custom evaluation scenarios:

### Team Case 1: Post-Deletion Backup Restoration Recreation
- **Input:** Customer `sarah.connor@sky.net` had a completed deletion workflow reported on `2026-08-20`. On `2026-08-22`, an automated backup restore job (`activity_3387`) repopulated downstream resource `search_4882`.
- **Audit Timestamp:** `2026-08-25T10:00:00Z`
- **Engine Decision:** `INCOMPLETE`
- **Output:** Finding `REPORT_RESTORE_RISK` and `REPORT_REMAINING_RECORD` on `search_service:search_4882`, remediation `BLOCK_RESTORE` + `DELETE_RECORD`, followed by verifications.

### Team Case 2: Historical Hash Analytics Finding with Changed Email
- **Input:** User `Carlos Mendez` submitted deletion with email `carlos.m@corp.org`. Two years prior, his email was `cmendez@old.net`. Subsystem `analytics_platform` retained an event record indexed by the SHA-256 hash of `cmendez@old.net`.
- **Audit Timestamp:** `2026-09-15T11:00:00Z`
- **Engine Decision:** `INCOMPLETE`
- **Output:** Correctly identified the historical hash from `user_audit_log.csv`, matched `analytics_platform` correlation key, issued `REPORT_EXPOSED_PII` $\to$ `ANONYMIZE_RECORD` $\to$ `VERIFY_RECORD_ANONYMIZED`.

### Team Case 3: Retained Security Audit Log with Legitimate Tombstone
- **Input:** User requested deletion. All application databases purged PII. Identity service retained account tombstone with direct identifiers redacted, and security service retained audit event with retention until 2034.
- **Audit Timestamp:** `2026-09-20T10:00:00Z`
- **Engine Decision:** `COMPLETE`
- **Output:** Zero findings. Generated `VERIFY_RECORD_ABSENT` on primary account, `VERIFY_RECORD_PRESENT` on security audit record, and `VERIFY_RECORD_REDACTED` on account tombstone.

---

## 5. Verification Protocol Summary

- Evaluated with official evaluator `code/evaluation/main.py`.
- Evaluated with submission grading script `code/verify_submission.py`.
- Regression suite in `code/test_audit_engine.py` passes all unit tests in 0.18s.
- Clean submission archive `code.zip` rebuilt and verified at repository root.
